/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author EPIS
 */
public class Notas {
    protected String Nota1;
    protected String Nota2;
    protected String Nota3;
    protected String NotaParcial;
    protected String NotaRecuperativa;

    public Notas() {
    }

    public Notas(String Nota1, String Nota2, String Nota3, String NotaParcial, String NotaRecuperativa) {
        this.Nota1 = Nota1;
        this.Nota2 = Nota2;
        this.Nota3 = Nota3;
        this.NotaParcial = NotaParcial;
        this.NotaRecuperativa = NotaRecuperativa;
    }

    public String getNota1() {
        return Nota1;
    }

    public void setNota1(String Nota1) {
        this.Nota1 = Nota1;
    }

    public String getNota2() {
        return Nota2;
    }

    public void setNota2(String Nota2) {
        this.Nota2 = Nota2;
    }

    public String getNota3() {
        return Nota3;
    }

    public void setNota3(String Nota3) {
        this.Nota3 = Nota3;
    }

    public String getNotaParcial() {
        return NotaParcial;
    }

    public void setNotaParcial(String NotaParcial) {
        this.NotaParcial = NotaParcial;
    }

    public String getNotaRecuperativa() {
        return NotaRecuperativa;
    }

    public void setNotaRecuperativa(String NotaRecuperativa) {
        this.NotaRecuperativa = NotaRecuperativa;
    }
    public String Aprobar()
    {
        return "Metodo Aprobar la Nota";
    }
    public String Desaprobar()
    {
        return "Metodo Desaprobar la Nota ";
    }
    public String Convalidar()
    {
        return "Metodo Convalidar la Nota ";
    }
    public String Recolectar()
    {
        return "Metodo Recolectar la Nota";
    }

    public void setNotaRecuperatoria(String notarecuperatoria) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
