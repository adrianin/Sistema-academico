/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author users
 */
public class Escuela {
    protected String Nombre;
    protected String Aniversario;
    protected String Horario;
    protected String Credito;

    public Escuela() {
    }

    public Escuela(String Nombre, String Aniversario, String Horario, String Credito) {
        this.Nombre = Nombre;
        this.Aniversario = Aniversario;
        this.Horario = Horario;
        this.Credito = Credito;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getAniversario() {
        return Aniversario;
    }

    public void setAniversario(String Aniversario) {
        this.Aniversario = Aniversario;
    }

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String Horario) {
        this.Horario = Horario;
    }

    public String getCredito() {
        return Credito;
    }

    public void setCredito(String Credito) {
        this.Credito = Credito;
    }
    public String Brindar()
    {
        return "Metodo Brindar de la Escuela";
    }
    public String Apoyar()
    {
        return "Metodo Apoyar de la Escuela ";
    }
    public String Reconocer()
    {
        return "Metodo Reconoces de la Escuela ";
    }
    public String Competir()
    {
        return "Metodo Competir de la Escuela ";
    }

    public void setCreditos(String creditos) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getCreditos() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
