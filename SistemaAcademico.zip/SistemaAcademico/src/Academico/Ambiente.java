/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author EPIS
 */
public class Ambiente {
    protected String numerodeaula;
    protected String lugardeledificio;
    protected String nombredeldocente;
    protected String capacidad;

    public Ambiente() {
    }

    public Ambiente(String Numerodeaula, String lugardeledificio, String nombredeldocente, String capacidad) {
        this.numerodeaula = Numerodeaula;
        this.lugardeledificio = lugardeledificio;
        this.nombredeldocente= nombredeldocente;
        this.capacidad = capacidad;
    }

    public String getNumerodeaula() {
        return numerodeaula;
    }

    public void setNumerodeaula(String Numerodeaula) {
        this.numerodeaula = Numerodeaula;
    }

    public String getLugardeledificio() {
        return lugardeledificio;
    }

    public void setLugardeledificio(String lugardeledificio) {
        this.lugardeledificio=lugardeledificio;
    }

    public String getNombredeldocente() {
        return nombredeldocente;
    }

    public void setNombredeldocente(String nombredeldocente) {
        this.nombredeldocente = nombredeldocente;
    }

    public String getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(String Capacidad) {
        this.capacidad = Capacidad;
    }
    public String Registrar()
    {
        return "Metodo registrar en el Ambiente";
    }
    public String Asistir()
    {
        return "Asistir todos los dias";
    }
    public String Organizar()
    {
        return "El ambiente tiene que estar organizado";
    }
    public String Evaluacion()
    {
        return "habra evaluacion";
    }
}
