/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author EPIS
 */
public class Asignaturas {
    protected String cursosacademicos;
    protected String reglamento;
   
    protected String horario;
    private String docentes;

    public Asignaturas() {
    }

    public Asignaturas(String Cursosacademicos, String Docentes, String Horario, String reglamento) {
        this.cursosacademicos = Cursosacademicos;
        this.docentes = Docentes;
        this.horario = Horario;
        this.reglamento= reglamento;
    }

    public String getCursosacademicos() {
        return cursosacademicos;
    }

    public void setCursosacademicos(String Cursosacademicos) {
        this.cursosacademicos = Cursosacademicos;
    }

    public String getDocentes() {
        return docentes;
    }

    public void setDocentes(String docentes) {
        this.docentes = docentes;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String Horario) {
        this.horario = Horario;
    }

    public String getReglamento() {
        return reglamento;
    }

    public void setReglamento(String reglamento) {
        this.reglamento = reglamento;
    }
    public String Asistir()
    {
        return "Asistir a todas las clases";
    }
    public String Avancedeasignatura()
    {
        return "Avancedeasignatura";
    }
    public String Fechadetrabajos()
    {
        return "la Fechadetrabajos";
    }

   
}
