/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author EPIS
 */
public class Alumno {
    protected String codigo;
    protected String apellidos;
    protected String nombres;
    protected String correoelectronico;

    public Alumno() {
    }

    public Alumno(String codigo, String apellidos, String nombres, String correo) {
        this.codigo = codigo;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.correoelectronico = correoelectronico;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getCorreoelectronico() {
        return correoelectronico;
    }

    public void setCorreoelectronico(String correoelectronico) {
        this.correoelectronico = correoelectronico;
    }
    public String Matricular()
    {
        return " Matricular Alumno";
    }
    public String Asistencia()
    {
        return "El Alumno Asiste todos los Dias ";
    }
    public String Pagar()
    {
        return "Metodo Pagar Alumno";
    }
    public String Dispensar()
    {
        return "Metodo Dispensar Alumno";
    }
    
}
