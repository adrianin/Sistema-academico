/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Academico;

/**
 *
 * @author EPIS
 */
public class Docente {
    protected String DNI;
    protected String Apellidos;
    protected String Nombres;
    protected String Grado;
    protected String Especialidad;

    public Docente() {
    }

    public Docente(String DNI, String Apellidos, String Nombres, String Grado, String Especialidad) {
        this.DNI = DNI;
        this.Apellidos = Apellidos;
        this.Nombres = Nombres;
        this.Grado = Grado;
        this.Especialidad = Especialidad;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getGrado() {
        return Grado;
    }

    public void setGrado(String Grado) {
        this.Grado = Grado;
    }

    public String getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }
    public String Asistir()
    {
        return "Metodo Asistir del Docente";
    }
    public String Enseñar()
    {
        return "Metodo Enseñar del Docente";
    }
    public String Investigar()
    {
        return "Metodo Investigar del Docente";
    }
    public String Preparar()
    {
        return "Metodo Preparar del Docente ";
    }

    public String getNota2() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getNota1() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getNotaParcial() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getNombre3() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getNota3() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
